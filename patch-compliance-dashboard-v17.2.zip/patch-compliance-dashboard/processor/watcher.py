"""Watch data/incoming, process completed JSON files, and route outcomes."""

import json
import logging
import shutil
import sys
import threading
import time
from pathlib import Path

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from processor.process_reports import process_report, was_processed_from_source  # noqa: E402
from processor.report_adapter import normalize_report  # noqa: E402

INCOMING_DIR = BASE_DIR / "data" / "incoming"
ARCHIVE_DIR = BASE_DIR / "data" / "archive"
ERROR_DIR = BASE_DIR / "data" / "error"
DUPLICATE_DIR = BASE_DIR / "data" / "duplicates"
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    filename=LOG_DIR / "processor.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)
PROCESS_LOCK = threading.Lock()


def wait_until_stable(file_path, timeout=60, stable_checks_required=3):
    """Wait for size and mtime to remain unchanged; fail after timeout."""
    start = time.monotonic()
    previous = None
    stable_checks = 0
    while time.monotonic() - start < timeout:
        if not file_path.exists():
            raise FileNotFoundError(f"File disappeared: {file_path.name}")
        stat = file_path.stat()
        current = (stat.st_size, stat.st_mtime_ns)
        if current == previous:
            stable_checks += 1
            if stable_checks >= stable_checks_required:
                return
        else:
            previous = current
            stable_checks = 0
        time.sleep(1)
    raise TimeoutError(f"File did not become stable within {timeout}s: {file_path.name}")


def _unique_destination(directory, file_path, report_date):
    directory = directory / report_date
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / file_path.name
    if not target.exists():
        return target
    stem, suffix = file_path.stem, file_path.suffix
    index = 1
    while True:
        candidate = directory / f"{stem}_{index}{suffix}"
        if not candidate.exists():
            return candidate
        index += 1


def _report_date_or_fallback(file_path):
    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
        return normalize_report(payload)["report_date"]
    except Exception:
        return "unclassified"


def _archive_contains_same_report(file_path, report_date):
    """Check whether an identical report is already safely archived."""
    try:
        incoming = normalize_report(json.loads(file_path.read_text(encoding="utf-8")))
    except Exception:
        return False
    for archived_path in (ARCHIVE_DIR / report_date).glob("*.json"):
        try:
            archived = normalize_report(
                json.loads(archived_path.read_text(encoding="utf-8"))
            )
        except Exception:
            continue
        if archived == incoming:
            return True
    return False


def handle_file(file_path):
    file_path = Path(file_path)
    if file_path.suffix.lower() != ".json" or not file_path.exists():
        return None

    logger.info("JSON queued: %s", file_path)
    print(f"\nJSON detected: {file_path.name}; waiting for a complete file.")
    result = None
    try:
        wait_until_stable(file_path)
        with PROCESS_LOCK:
            result = process_report(file_path)
            report_date = _report_date_or_fallback(file_path)
            if result == "DUPLICATE":
                archive_retry = (
                    was_processed_from_source(file_path)
                    and not _archive_contains_same_report(file_path, report_date)
                )
                if archive_retry:
                    destination = _unique_destination(ARCHIVE_DIR, file_path, report_date)
                    logger.info("Completing archive for previously committed input: %s", file_path)
                else:
                    destination = _unique_destination(DUPLICATE_DIR, file_path, report_date)
                    logger.info("Duplicate input: %s", file_path)
            else:
                destination = _unique_destination(ARCHIVE_DIR, file_path, report_date)
                logger.info("%s input: %s", result, file_path)
            shutil.move(str(file_path), str(destination))
            print(f"{result}: moved to {destination.relative_to(BASE_DIR)}")
        return result
    except Exception as error:
        logger.exception("Failed to process %s: %s", file_path, error)
        print(f"ERROR processing {file_path.name}: {error}")
        if result is not None:
            # The DB commit succeeded. Leave the source in incoming so a later
            # watcher retry can recognize it as a duplicate and route it safely.
            logger.error("Database committed but file routing failed; leaving in incoming: %s", file_path)
            return "ROUTE_ERROR"
        if file_path.exists():
            report_date = _report_date_or_fallback(file_path)
            destination = _unique_destination(ERROR_DIR, file_path, report_date)
            try:
                shutil.move(str(file_path), str(destination))
                print(f"Failed input retained at {destination.relative_to(BASE_DIR)}")
                logger.info("Failed input moved to: %s", destination)
            except Exception:
                logger.exception("Could not route failed input %s", file_path)
        return "ERROR"


class ReportHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory:
            handle_file(Path(event.src_path))

    def on_moved(self, event):
        if not event.is_directory:
            handle_file(Path(event.dest_path))


def start_watcher():
    for directory in (INCOMING_DIR, ARCHIVE_DIR, ERROR_DIR, DUPLICATE_DIR):
        directory.mkdir(parents=True, exist_ok=True)

    handler = ReportHandler()
    observer = Observer()
    observer.schedule(handler, str(INCOMING_DIR), recursive=False)
    observer.start()
    print(f"Watching {INCOMING_DIR}")
    logger.info("Watcher started: %s", INCOMING_DIR)

    # Start observing before scanning to avoid missing files arriving in between.
    for file_path in sorted(INCOMING_DIR.glob("*.json")):
        handle_file(file_path)

    try:
        while observer.is_alive():
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping watcher.")
        logger.info("Watcher stopping.")
    finally:
        observer.stop()
        observer.join()
        logger.info("Watcher stopped.")


if __name__ == "__main__":
    start_watcher()
