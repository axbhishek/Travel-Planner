"""Validate simulation JSON reports and upsert them into SQLite."""

import hashlib
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "patch_dashboard.db"
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from database.init_db import create_database  # noqa: E402
from processor.report_adapter import normalize_report  # noqa: E402


CATEGORY_NAMES = {
    "non_production": "Non-Production",
    "production": "Production",
    "cloud": "Cloud",
}


def _connect():
    if not DB_PATH.exists():
        create_database()
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    return conn


def _canonical_hash(report):
    # Omit absent optional fields so adding an optional adapter field later
    # does not turn unchanged historical reports into false corrections.
    stable_report = {
        "category_key": report["category_key"],
        "report_date": report["report_date"],
        "servers": [
            {key: value for key, value in server.items() if value is not None}
            for server in report["servers"]
        ],
    }
    encoded = json.dumps(stable_report, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _load_normalized_report(file_path):
    try:
        payload = json.loads(Path(file_path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise ValueError(
            f"Invalid JSON: {error.msg} (line {error.lineno}, column {error.colno})"
        ) from error
    except UnicodeDecodeError as error:
        raise ValueError(f"File is not valid UTF-8: {error}") from error
    return normalize_report(payload)


def _same_source_file(stored_path, incoming_path):
    """Compare recorded and incoming paths, including legacy path formats."""
    stored = Path(stored_path).expanduser()
    incoming = Path(incoming_path).expanduser()
    try:
        if stored.resolve(strict=False) == incoming.resolve(strict=False):
            return True
    except (OSError, RuntimeError):
        pass

    # Older report rows stored an absolute path, while newer rows store only
    # the filename. The report hash/category/date are also checked by the
    # caller, so matching the basename supports both formats safely.
    return stored.name == incoming.name


def was_processed_from_source(file_path):
    """Return whether this exact payload was already committed from this filename."""
    file_path = Path(file_path)
    report = _load_normalized_report(file_path)
    conn = _connect()
    try:
        rows = conn.execute(
            """SELECT source_file FROM reports
               WHERE category_key = ? AND report_date = ? AND content_hash = ?
            """,
            (report["category_key"], report["report_date"],
             _canonical_hash(report)),
        ).fetchall()
        return any(_same_source_file(row[0], file_path) for row in rows)
    finally:
        conn.close()


def process_report(file_path):
    """Process one report; return PROCESSED, CORRECTION, or DUPLICATE."""
    file_path = Path(file_path)
    print(f"\nProcessing: {file_path}")
    report = _load_normalized_report(file_path)
    category_key = report["category_key"]
    report_date = report["report_date"]
    content_hash = _canonical_hash(report)
    processed_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    conn = _connect()
    try:
        conn.execute("BEGIN IMMEDIATE")

        # A hostname identifies one server globally; category membership is exclusive.
        for server in report["servers"]:
            existing = conn.execute(
                "SELECT category_key FROM servers WHERE hostname_key = ?",
                (server["hostname_key"],),
            ).fetchone()
            if existing and existing[0] != category_key:
                raise ValueError(
                    f"Server {server['hostname']!r} was already assigned to "
                    f"{CATEGORY_NAMES[existing[0]]}; category membership cannot overlap"
                )

        duplicate = conn.execute(
            """SELECT id FROM reports
               WHERE category_key = ? AND report_date = ? AND content_hash = ?""",
            (category_key, report_date, content_hash),
        ).fetchone()
        if duplicate:
            conn.rollback()
            print(
                f"Identical report already stored: {CATEGORY_NAMES[category_key]} "
                f"{report_date}; no database changes."
            )
            return "DUPLICATE"

        previous = conn.execute(
            """SELECT id, revision FROM reports
               WHERE category_key = ? AND report_date = ? AND is_current = 1""",
            (category_key, report_date),
        ).fetchone()
        revision = conn.execute(
            """SELECT COALESCE(MAX(revision), 0) + 1 FROM reports
               WHERE category_key = ? AND report_date = ?""",
            (category_key, report_date),
        ).fetchone()[0]
        if previous:
            conn.execute("UPDATE reports SET is_current = 0 WHERE id = ?", (previous[0],))

        cursor = conn.execute(
            """INSERT INTO reports(
                   category_key, report_date, revision, content_hash,
                   source_file, processed_at, is_current
            ) VALUES (?, ?, ?, ?, ?, ?, 1)""",
            (category_key, report_date, revision, content_hash,
             file_path.name, processed_at),
        )
        report_id = cursor.lastrowid

        new_count = changed_count = unchanged_count = historical_count = 0
        for server in report["servers"]:
            existing = conn.execute(
                """SELECT id, last_patch_date, last_report_date
                   FROM servers WHERE hostname_key = ?""",
                (server["hostname_key"],),
            ).fetchone()

            if existing is None:
                server_cursor = conn.execute(
                    """INSERT INTO servers(
                           hostname, hostname_key, ip_address, category_key, last_patch_date,
                           last_report_date, last_report_id, first_seen_at, updated_at
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (server["hostname"], server["hostname_key"], server.get("ip_address"), category_key,
                     server["last_patch_date"], report_date, report_id,
                     processed_at, processed_at),
                )
                server_id = server_cursor.lastrowid
                conn.execute(
                    """INSERT INTO patch_history(server_id, patch_date, report_id, recorded_at)
                       VALUES (?, ?, ?, ?)""",
                    (server_id, server["last_patch_date"], report_id, processed_at),
                )
                new_count += 1
            else:
                server_id, old_patch_date, old_report_date = existing
                if server["last_patch_date"] != old_patch_date:
                    conn.execute(
                        """INSERT OR IGNORE INTO patch_history(
                               server_id, patch_date, report_id, recorded_at
                           ) VALUES (?, ?, ?, ?)""",
                        (server_id, server["last_patch_date"], report_id, processed_at),
                    )
                    if report_date >= old_report_date:
                        conn.execute(
                        """UPDATE servers SET hostname = ?, last_patch_date = ?,
                                   ip_address = COALESCE(?, ip_address),
                                   last_report_date = ?, last_report_id = ?, updated_at = ?
                               WHERE id = ?""",
                            (server["hostname"], server["last_patch_date"], server.get("ip_address"), report_date,
                             report_id, processed_at, server_id),
                        )
                        changed_count += 1
                    else:
                        historical_count += 1
                elif report_date >= old_report_date:
                    conn.execute(
                        """UPDATE servers SET hostname = ?, last_report_date = ?,
                               ip_address = COALESCE(?, ip_address),
                               last_report_id = ?, updated_at = ? WHERE id = ?""",
                        (server["hostname"], report_date, server.get("ip_address"), report_id, processed_at, server_id),
                    )
                    unchanged_count += 1
                else:
                    unchanged_count += 1

            conn.execute(
                """INSERT INTO report_servers(
                       report_id, server_id, hostname, hostname_key, ip_address, last_patch_date
                   ) VALUES (?, ?, ?, ?, ?, ?)""",
                (report_id, server_id, server["hostname"], server["hostname_key"],
                 server.get("ip_address"), server["last_patch_date"]),
            )

        conn.commit()
        if previous:
            result = "CORRECTION"
            print(f"Correction revision {revision} recorded for {CATEGORY_NAMES[category_key]} {report_date}.")
        else:
            result = "PROCESSED"
            print(f"Report snapshot stored: {CATEGORY_NAMES[category_key]} {report_date}.")
        print(
            f"Servers in snapshot: {len(report['servers'])}; new inventory: {new_count}; "
            f"patch updates: {changed_count}; unchanged: {unchanged_count}; "
            f"older-report observations: {historical_count}."
        )
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def process_directory(directory):
    directory = Path(directory)
    outcomes = []
    for file_path in sorted(directory.glob("*.json")):
        try:
            result = process_report(file_path)
            outcomes.append((file_path, result, None))
        except Exception as error:
            print(f"ERROR processing {file_path}: {error}")
            outcomes.append((file_path, "ERROR", str(error)))
    if not outcomes:
        print(f"No JSON reports found in {directory}")
    return outcomes


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python processor/process_reports.py <report_directory>")
        raise SystemExit(1)
    process_directory(sys.argv[1])
