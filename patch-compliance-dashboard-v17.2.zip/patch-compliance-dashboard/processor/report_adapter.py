from datetime import date


CATEGORY_ALIASES = {
    "production": "production",
    "non-production": "non_production",
    "non_production": "non_production",
    "cloud": "cloud",
}


def _iso_date(value, field):
    if not isinstance(value, str):
        raise ValueError(f"{field} must be an ISO date string (YYYY-MM-DD)")
    try:
        return date.fromisoformat(value).isoformat()
    except ValueError as error:
        raise ValueError(f"Invalid {field}: {value!r}; expected YYYY-MM-DD") from error


def normalize_report(payload):
    """Validate and normalize the current simulation JSON shape."""
    if not isinstance(payload, dict):
        raise ValueError("Report JSON must contain an object")

    raw_category = payload.get("category")
    if not isinstance(raw_category, str):
        raise ValueError("Missing or invalid category")
    category_key = CATEGORY_ALIASES.get(raw_category.strip().lower())
    if category_key is None:
        raise ValueError(f"Unsupported category: {raw_category!r}")

    report_date = _iso_date(payload.get("report_date"), "report_date")
    raw_servers = payload.get("servers")
    if not isinstance(raw_servers, list):
        raise ValueError("servers must be a list")
    if not raw_servers:
        raise ValueError("servers must contain at least one server")

    servers = []
    seen = set()
    for index, row in enumerate(raw_servers):
        if not isinstance(row, dict):
            raise ValueError(f"servers[{index}] must be an object")
        hostname = row.get("hostname")
        if not isinstance(hostname, str) or not hostname.strip():
            raise ValueError(f"servers[{index}].hostname must be a non-empty string")
        hostname = hostname.strip()
        hostname_key = hostname.casefold()
        if hostname_key in seen:
            raise ValueError(f"Duplicate hostname in report: {hostname}")
        seen.add(hostname_key)
        ip_address = row.get("ip_address")
        if ip_address is not None and (not isinstance(ip_address, str) or not ip_address.strip()):
            raise ValueError(f"servers[{index}].ip_address must be a non-empty string when supplied")
        servers.append({
            "hostname": hostname,
            "hostname_key": hostname_key,
            "ip_address": ip_address.strip() if ip_address else None,
            "last_patch_date": _iso_date(
                row.get("last_patch_date"), f"servers[{index}].last_patch_date"
            ),
        })

    servers.sort(key=lambda server: server["hostname_key"])
    return {
        "category_key": category_key,
        "report_date": report_date,
        "servers": servers,
    }
