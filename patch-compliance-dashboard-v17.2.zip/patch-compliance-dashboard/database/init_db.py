"""Create the patch dashboard database schema.

Use ``python database/init_db.py --reset`` only for a development database
that has been backed up. The reset drops application tables and recreates them.
"""

import argparse
import sqlite3
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "patch_dashboard.db"

CATEGORIES = (
    ("non_production", "Non-Production"),
    ("production", "Production"),
    ("cloud", "Cloud"),
)


def create_database(reset=False):
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    if reset:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("DROP TABLE IF EXISTS patch_history")
        conn.execute("DROP TABLE IF EXISTS report_servers")
        conn.execute("DROP TABLE IF EXISTS servers")
        conn.execute("DROP TABLE IF EXISTS reports")
        conn.execute("DROP TABLE IF EXISTS categories")
        conn.commit()

    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS categories (
            category_key TEXT PRIMARY KEY,
            display_name TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_key TEXT NOT NULL REFERENCES categories(category_key),
            report_date TEXT NOT NULL,
            revision INTEGER NOT NULL,
            content_hash TEXT NOT NULL,
            source_file TEXT NOT NULL,
            processed_at TEXT NOT NULL,
            is_current INTEGER NOT NULL DEFAULT 1 CHECK (is_current IN (0, 1)),
            UNIQUE(category_key, report_date, revision),
            UNIQUE(category_key, report_date, content_hash)
        );

        CREATE INDEX IF NOT EXISTS idx_reports_latest
            ON reports(category_key, report_date DESC, is_current);

        CREATE TABLE IF NOT EXISTS servers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hostname TEXT NOT NULL,
            hostname_key TEXT NOT NULL UNIQUE,
            ip_address TEXT,
            category_key TEXT NOT NULL REFERENCES categories(category_key),
            last_patch_date TEXT NOT NULL,
            last_report_date TEXT NOT NULL,
            last_report_id INTEGER NOT NULL REFERENCES reports(id),
            first_seen_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_servers_category_hostname
            ON servers(category_key, hostname);

        CREATE TABLE IF NOT EXISTS report_servers (
            report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
            server_id INTEGER NOT NULL REFERENCES servers(id),
            hostname TEXT NOT NULL,
            hostname_key TEXT NOT NULL,
            ip_address TEXT,
            last_patch_date TEXT NOT NULL,
            PRIMARY KEY(report_id, hostname_key)
        );

        CREATE INDEX IF NOT EXISTS idx_report_servers_server
            ON report_servers(server_id, report_id);

        CREATE TABLE IF NOT EXISTS patch_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            server_id INTEGER NOT NULL REFERENCES servers(id),
            patch_date TEXT NOT NULL,
            report_id INTEGER NOT NULL REFERENCES reports(id),
            recorded_at TEXT NOT NULL,
            UNIQUE(server_id, patch_date)
        );

        CREATE INDEX IF NOT EXISTS idx_patch_history_server_date
            ON patch_history(server_id, patch_date DESC);
        """
    )
    # Add optional lookup columns to an already-created development schema.
    for table in ("servers", "report_servers"):
        columns = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
        if "ip_address" not in columns:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN ip_address TEXT")
    conn.executemany(
        "INSERT OR IGNORE INTO categories(category_key, display_name) VALUES (?, ?)",
        CATEGORIES,
    )
    conn.commit()
    conn.close()
    print(f"Database schema ready: {DB_PATH}")
    if reset:
        print("Development application tables reset.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reset",
        action="store_true",
        help="drop and recreate application tables (back up first)",
    )
    args = parser.parse_args()
    create_database(reset=args.reset)
