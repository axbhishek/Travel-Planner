"""Safely remove servers from the active Patch Dashboard inventory.

Run with ``python -m database.decommission HOSTNAME [HOSTNAME ...]``.
The command keeps report rows and snapshots for other servers, while removing
the selected server's own snapshot links and patch history.
"""

import argparse
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from database.init_db import DB_PATH


def _create_backup(db_path, backup_dir):
    """Create a consistent, non-overwriting SQLite backup of the live DB."""
    db_path = Path(db_path)
    backup_dir = Path(backup_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    base = f"{db_path.stem}_pre_decommission_{stamp}"
    index = 0
    while True:
        suffix = "" if index == 0 else f"_{index}"
        backup_path = backup_dir / f"{base}{suffix}{db_path.suffix}"
        try:
            # Reserve the name so an existing backup is never overwritten.
            with backup_path.open("xb"):
                pass
            break
        except FileExistsError:
            index += 1

    try:
        with sqlite3.connect(db_path, timeout=30) as source:
            with sqlite3.connect(backup_path, timeout=30) as destination:
                source.backup(destination)
        return backup_path
    except Exception:
        backup_path.unlink(missing_ok=True)
        raise


def _delete_server_records(connection, server_id):
    """Delete child records before the cumulative server row."""
    connection.execute("DELETE FROM report_servers WHERE server_id = ?", (server_id,))
    connection.execute("DELETE FROM patch_history WHERE server_id = ?", (server_id,))
    connection.execute("DELETE FROM servers WHERE id = ?", (server_id,))


def decommission_servers(hostnames, db_path=None, backup_dir=None):
    """Remove matching hostnames transactionally and return a result summary.

    Hostnames match the same case-folded identity used by the report adapter.
    A backup is made only when at least one requested hostname currently exists.
    """
    db_path = Path(DB_PATH if db_path is None else db_path)
    if not db_path.is_file():
        raise FileNotFoundError(f"Database does not exist: {db_path}")

    requested = []
    seen = set()
    for hostname in hostnames:
        display = str(hostname).strip()
        if not display:
            raise ValueError("Hostnames must not be empty")
        key = display.casefold()
        if key not in seen:
            requested.append((display, key))
            seen.add(key)
    if not requested:
        raise ValueError("Specify at least one hostname")

    placeholders = ",".join("?" for _ in requested)
    keys = [key for _, key in requested]
    with sqlite3.connect(db_path, timeout=30) as connection:
        existing = connection.execute(
            f"SELECT id, hostname_key, hostname FROM servers WHERE hostname_key IN ({placeholders})",
            keys,
        ).fetchall()

    if not existing:
        return {"removed": [], "not_found": [display for display, _ in requested], "backup": None}

    if backup_dir is None:
        backup_dir = db_path.parent / "backups"
    backup_path = _create_backup(db_path, backup_dir)
    removed = []
    not_found = []

    connection = sqlite3.connect(db_path, timeout=30)
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 30000")
    try:
        connection.execute("BEGIN IMMEDIATE")
        # Recheck inside the write transaction in case inventory changed after
        # the pre-backup lookup.
        rows = connection.execute(
            f"SELECT id, hostname_key, hostname FROM servers WHERE hostname_key IN ({placeholders})",
            keys,
        ).fetchall()
        current_by_key = {key: (server_id, hostname) for server_id, key, hostname in rows}
        for display, key in requested:
            current = current_by_key.get(key)
            if current is None:
                not_found.append(display)
                continue
            server_id, stored_hostname = current
            _delete_server_records(connection, server_id)
            removed.append(stored_hostname)

        foreign_key_errors = connection.execute("PRAGMA foreign_key_check").fetchall()
        if foreign_key_errors:
            raise sqlite3.IntegrityError(f"Foreign-key violations after deletion: {foreign_key_errors}")
        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise sqlite3.IntegrityError(f"Database integrity check failed: {integrity}")
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()

    return {"removed": removed, "not_found": not_found, "backup": backup_path}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("hostnames", nargs="+", help="one or more hostnames to permanently remove")
    args = parser.parse_args(argv)

    try:
        result = decommission_servers(args.hostnames, db_path=DB_PATH)
    except Exception as error:
        parser.exit(1, f"Decommission failed: {error}\n")

    if result["removed"]:
        print("Removed:")
        for hostname in result["removed"]:
            print(f"  {hostname}")
        print(f"Backup: {result['backup']}")
    else:
        print("Removed: none")
    if result["not_found"]:
        print("Not found:")
        for hostname in result["not_found"]:
            print(f"  {hostname}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
