# Patch Compliance Dashboard

A local Streamlit dashboard for tracking server patch compliance from JSON reports. It keeps a cumulative server inventory, records patch history, and organizes incoming reports into archived, duplicate, or error folders.

## Quick start from the ZIP

Install Python 3.10 or newer, extract the ZIP, open a terminal in the extracted folder, and run:

- **Windows:**

```bash
py run.py
```

- **macOS/Linux:**

```bash
python3 run.py
```

On first launch, the script creates a virtual environment, installs the requirements, then starts the report watcher and dashboard. Internet access is needed for the initial dependency install. Press **Ctrl+C** to stop the dashboard and watcher. Add JSON reports to `data/incoming/` to populate the inventory.

## Manual setup

```bash
python -m venv .venv
```

Activate the environment (`.venv\\Scripts\\Activate.ps1` on Windows PowerShell, or `source .venv/bin/activate` on macOS/Linux), then install dependencies:

```bash
python -m pip install -r requirements.txt
```

Start the report watcher in one terminal:

```bash
python processor/watcher.py
```

Start the dashboard in a second terminal:

```bash
streamlit run app/dashboard.py
```

## Arcade Easter egg

While the dashboard is focused, type `A`, `R`, `Y`, `A` in sequence to open the Patch Defender Easter egg. A full-screen Matrix rain welcome credits Abhishek Kumar Arya as the developer. Select **Play the game** to start. The game keeps a high score in the browser. Press `Escape` or select the close button to exit.

On first launch, the dashboard creates an empty SQLite database at `database/patch_dashboard.db`. Add new JSON reports to `data/incoming/`; the watcher validates and processes them, updates the inventory, and moves each file to the appropriate results folder.

## Report format

Each report must contain a category, an ISO-formatted report date, and at least one server. Supported categories are `production`, `non-production` (or `non_production`), and `cloud`.

```json
{
  "category": "production",
  "report_date": "2026-10-06",
  "servers": [
    {
      "hostname": "server-01.example.com",
      "ip_address": "192.0.2.10",
      "last_patch_date": "2026-09-20"
    }
  ]
}
```

`ip_address` is optional. Hostnames must be unique within each report. Place one report file at a time in `data/incoming/` and let the watcher finish processing it before adding another.

## Data and privacy

The SQLite database, report inputs and outputs, logs, backups, sample reports, and virtual environments are excluded by `.gitignore`. A fresh checkout starts without prior inventory or report history; its database is created when the dashboard or processor first needs it.

## Tests

Run the project tests with:

```bash
python -m unittest discover -s tests
```
