"""Patch compliance dashboard for the cumulative server inventory."""

import html
import sqlite3
from datetime import date
from difflib import SequenceMatcher
from pathlib import Path

import streamlit as st
from streamlit_autorefresh import st_autorefresh

from database.init_db import create_database


BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "patch_dashboard.db"
CATEGORIES = [
    ("all", "All Servers", None),
    ("non_production", "Non-Production", "Non-Production"),
    ("production", "Production", "Production"),
    ("cloud", "Cloud", "Cloud"),
]
AGE_OPTIONS = ["All", "30 days or less", "60 days or less", "90 days or less", "More than 90 days"]
STATUS_OPTIONS = ["All", "Compliant", "Non-compliant"]

st.set_page_config(
    page_title="Patch Compliance Dashboard",
    page_icon="◆",
    layout="wide",
    initial_sidebar_state="collapsed",
)
st_autorefresh(interval=10_000, key="patch_dashboard_refresh")


def inject_css():
    css = (BASE_DIR / "app" / "dashboard.css").read_text(encoding="utf-8")
    if st.session_state.get("dark_mode", False):
        css += "\n" + (BASE_DIR / "app" / "dashboard_dark.css").read_text(encoding="utf-8")
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def dashboard_header_component():
    return st.components.v2.component(
        "patch_dashboard_header",
        html="""<header class="dashboard-hero">
          <div class="hero-copy"><h1>Patch Compliance Dashboard</h1><p><span class="live-dot"></span><span class="hero-subtitle"></span></p></div>
          <button class="theme-switch" type="button" aria-label="Switch theme"><span class="switch-knob"></span><span class="switch-symbol"></span></button>
        </header>""",
        js="""
        export default function({parentElement, data, setTriggerValue}) {
          const root = parentElement.querySelector('.dashboard-hero');
          root.dataset.theme = data.dark ? 'dark' : 'light';
          root.querySelector('.hero-subtitle').textContent = data.subtitle;
          const button = root.querySelector('.theme-switch');
          button.querySelector('.switch-symbol').textContent = data.dark ? '☼' : '☾';
          button.setAttribute('aria-label', data.dark ? 'Switch to light mode' : 'Switch to dark mode');
          button.setAttribute('aria-pressed', String(data.dark));
          button.onclick = () => {
            const next = button.getAttribute('aria-pressed') !== 'true';
            button.setAttribute('aria-pressed', String(next));
            button.querySelector('.switch-symbol').textContent = next ? '☼' : '☾';
            button.setAttribute('aria-label', next ? 'Switch to light mode' : 'Switch to dark mode');
            setTriggerValue('theme_event', {dark_mode: next, event_id: `${Date.now()}-${Math.random()}`});
          };
          let doc = document;
          try { if (window.parent && window.parent !== window && window.parent.document) doc = window.parent.document; } catch (_) {}
          let topButton = doc.getElementById('patch-dashboard-back-to-top');
          if (!topButton) {
            topButton = doc.createElement('button');
            topButton.id = 'patch-dashboard-back-to-top';
            topButton.className = 'back-to-top';
            topButton.type = 'button';
            topButton.setAttribute('aria-label', 'Back to top');
            topButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5m-7 7 7-7 7 7"></path></svg>';
            doc.body.append(topButton);
          }
          topButton.className = 'back-to-top';
          topButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5m-7 7 7-7 7 7"></path></svg>';
          topButton.style.cssText = 'position:fixed;right:24px;bottom:24px;z-index:2147483000;display:grid;place-items:center;width:46px;height:46px;padding:0;border:0;border-radius:50%;background:#5b3df0;color:#fff;box-shadow:0 7px 20px rgba(30,20,90,.32);cursor:pointer;opacity:1;pointer-events:auto;transition:background .18s,transform .18s;';
          topButton.onmouseenter = () => { topButton.style.background = '#4326d8'; topButton.style.transform = 'translateY(-3px)'; };
          topButton.onmouseleave = () => { topButton.style.background = '#5b3df0'; topButton.style.transform = 'translateY(0)'; };
          topButton.onclick = () => {
            const top = doc.getElementById('dashboard-top');
            if (top) top.scrollIntoView({behavior:'smooth', block:'start'});
            doc.defaultView?.scrollTo({top:0, behavior:'smooth'});
            doc.querySelectorAll('section.main,[data-testid="stAppViewContainer"]').forEach(node => node.scrollTo?.({top:0, behavior:'smooth'}));
          };
          // Documented credits easter egg: type A, R, Y, A in sequence.
          if (!doc.__patchDashboardCreditsShortcutInstalled) {
            doc.__patchDashboardCreditsShortcutInstalled = true;
            let keySequence = '';
            const creditsId = 'patch-dashboard-credits-overlay';
            let gameCleanup = null;
            const closeCredits = () => {
              if (gameCleanup) { gameCleanup(); gameCleanup = null; }
              doc.getElementById(creditsId)?.remove();
            };
            const showCredits = () => {
              if (doc.getElementById(creditsId)) return;
              const overlay = doc.createElement('div');
              overlay.id = creditsId;
              overlay.className = 'credits-overlay';
              overlay.setAttribute('role', 'dialog');
              overlay.setAttribute('aria-modal', 'true');
              overlay.setAttribute('aria-label', 'Patch Defender Easter egg');
              overlay.innerHTML = `<div class="credits-page">
                <section class="arcade-welcome" aria-labelledby="welcome-title">
                  <canvas class="matrix-canvas" aria-hidden="true"></canvas>
                  <div class="confetti-field" aria-hidden="true"></div>
                  <button class="welcome-close" type="button" aria-label="Close Easter egg">×</button>
                  <div class="welcome-content">
                    <p class="welcome-kicker">✦ &nbsp; EASTER EGG FOUND &nbsp; ✦</p>
                    <h1 id="welcome-title">Well, look who found it.</h1>
                    <div class="welcome-credits">
                      <span class="welcome-byline">Developed by</span>
                      <strong class="welcome-name">Abhishek Kumar Arya</strong>
                      <p class="welcome-tagline">The dashboard was the warm-up.</p>
                      <p class="welcome-tagline">Finding the game is your reward.</p>
                    </div>
                    <button class="arcade-play" type="button">Play the game <span aria-hidden="true">→</span></button>
                  </div>
                </section>
                <div class="arcade-game-screen" hidden>
                  <canvas class="arcade-canvas" aria-label="Patch Defender game"></canvas>
                  <header class="arcade-header">
                    <div class="arcade-title"><span class="arcade-kicker">THE PERSON BEHIND THE PROJECT</span><h1>ABHISHEK KUMAR ARYA</h1></div>
                    <div class="arcade-hud" aria-live="polite">
                      <div class="hud-stat"><span>SCORE</span><strong class="hud-score">000000</strong></div>
                      <div class="hud-stat"><span>BEST</span><strong class="hud-best">000000</strong></div>
                      <div class="hud-stat hud-lives"><span>SHIELDS</span><strong class="hud-lives-value">◆ ◆ ◆</strong></div>
                    </div>
                    <button class="credits-close" type="button" aria-label="Close game">×</button>
                  </header>
                  <div class="arcade-gameover" hidden><div class="gameover-panel"><span>FLIGHT COMPLETE</span><h2>SHIP DISABLED</h2><p class="gameover-score"></p><div class="gameover-actions"><button class="arcade-restart" type="button">RELOAD</button><button class="arcade-exit" type="button">EXIT</button></div></div></div>
                </div>
              </div>`;
              // Always open on the discovery card; gameplay starts only from its play button.
              overlay.querySelector('.arcade-welcome').hidden = false;
              overlay.querySelector('.arcade-game-screen').hidden = true;
              overlay.querySelector('.credits-close').addEventListener('click', closeCredits);
              overlay.querySelector('.welcome-close').addEventListener('click', closeCredits);
              doc.body.append(overlay);
              overlay.querySelector('.arcade-play').focus();

              const gameWindow = doc.defaultView || window;
              const welcome = overlay.querySelector('.arcade-welcome');
              const matrixCanvas = overlay.querySelector('.matrix-canvas');
              const matrixCtx = matrixCanvas.getContext('2d');
              const matrixFontSize = 16;
              const matrixChars = `0123456789ABCDEFGHJKLMNOPQRSTUVWXYZ$+-*/=%".'#&_(),.;:?!\\|{}<>[]^~`;
              let matrixDrops = [], matrixFrame = 0, matrixWidth = 0, matrixHeight = 0;
              const resizeMatrix = () => {
                const rect = welcome.getBoundingClientRect();
                const ratio = Math.min(gameWindow.devicePixelRatio || 1, 2);
                matrixWidth = rect.width; matrixHeight = rect.height;
                matrixCanvas.width = Math.round(matrixWidth * ratio); matrixCanvas.height = Math.round(matrixHeight * ratio);
                matrixCtx.setTransform(ratio, 0, 0, ratio, 0, 0);
                matrixDrops = Array(Math.floor(matrixWidth / matrixFontSize)).fill(1);
              };
              const drawMatrix = () => {
                if (!overlay.isConnected || welcome.hidden) return;
                matrixCtx.fillStyle = 'rgba(0,0,0,0.09)'; matrixCtx.fillRect(0, 0, matrixWidth, matrixHeight);
                matrixCtx.fillStyle = '#00FF41'; matrixCtx.font = `${matrixFontSize}px monospace`;
                for (let i = 0; i < matrixDrops.length; i++) {
                  matrixCtx.fillText(matrixChars.charAt(Math.floor(Math.random() * matrixChars.length)), i * matrixFontSize, matrixDrops[i] * matrixFontSize);
                  if (matrixDrops[i] * matrixFontSize > matrixHeight && Math.random() > .975) matrixDrops[i] = 0;
                  matrixDrops[i]++;
                }
                matrixFrame = gameWindow.requestAnimationFrame(() => setTimeout(drawMatrix, 33));
              };
              const gameScreen = overlay.querySelector('.arcade-game-screen');
              const playButton = overlay.querySelector('.arcade-play');
              const canvas = overlay.querySelector('.arcade-canvas');
              const ctx = canvas.getContext('2d');
              const scoreDisplay = overlay.querySelector('.hud-score');
              const bestDisplay = overlay.querySelector('.hud-best');
              const livesDisplay = overlay.querySelector('.hud-lives-value');
              const gameOver = overlay.querySelector('.arcade-gameover');
              let width = 0, height = 0, pixelRatio = 1;
              let score = 0, lives = 3, best = 0, lastFrame = 0, spawnTimer = 0, fireTimer = 0, invulnerable = 0;
              let animationFrame = 0, dragging = false, running = true;
              let stars = [], bullets = [], targets = [], sparks = [];
              const ship = { x: 0, y: 0, targetX: 0, targetY: 0 };
              try { best = Number(gameWindow.localStorage.getItem('patch-dashboard-arcade-high-score')) || 0; } catch (_) {}
              bestDisplay.textContent = String(best).padStart(6, '0');
              const updateHud = () => {
                scoreDisplay.textContent = String(score).padStart(6, '0');
                livesDisplay.textContent = lives > 0 ? `${'◆ '.repeat(lives).trim()}${lives < 3 ? `  ${'◇ '.repeat(3-lives).trim()}` : ''}` : '—';
                if (score > best) {
                  best = score;
                  bestDisplay.textContent = String(best).padStart(6, '0');
                  try { gameWindow.localStorage.setItem('patch-dashboard-arcade-high-score', String(best)); } catch (_) {}
                }
              };
              const resize = () => {
                const rect = canvas.getBoundingClientRect();
                width = rect.width; height = rect.height;
                pixelRatio = Math.min(gameWindow.devicePixelRatio || 1, 2);
                canvas.width = Math.round(width * pixelRatio); canvas.height = Math.round(height * pixelRatio);
                ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
                if (!ship.x) { ship.x = width / 2; ship.targetX = ship.x; }
                ship.y = Math.min(height - 78, Math.max(height * .67, ship.y || height * .82));
                ship.targetY = ship.y;
                stars = Array.from({length: Math.max(45, Math.floor(width * height / 10500))}, () => ({
                  x: Math.random() * width, y: Math.random() * height, size: Math.random() * 1.7 + .35, speed: Math.random() * 35 + 12,
                }));
              };
              const pointerToShip = event => {
                const rect = canvas.getBoundingClientRect();
                ship.targetX = Math.max(24, Math.min(width - 24, event.clientX - rect.left));
                ship.targetY = Math.max(height * .56, Math.min(height - 62, event.clientY - rect.top));
              };
              canvas.addEventListener('pointerdown', event => {
                dragging = true; canvas.setPointerCapture(event.pointerId); pointerToShip(event);
              });
              canvas.addEventListener('pointermove', event => { if (dragging) pointerToShip(event); });
              canvas.addEventListener('pointerup', () => { dragging = false; });
              canvas.addEventListener('pointercancel', () => { dragging = false; });
              const drawShip = now => {
                if (invulnerable > 0 && Math.floor(now / 75) % 2) return;
                ctx.save(); ctx.translate(ship.x, ship.y);
                const flame = 11 + Math.sin(now / 48) * 5;
                ctx.shadowColor = '#64f4d2'; ctx.shadowBlur = 22;
                ctx.fillStyle = '#ff9b5e'; ctx.beginPath(); ctx.moveTo(-7, 15); ctx.lineTo(0, 15 + flame); ctx.lineTo(7, 15); ctx.closePath(); ctx.fill();
                ctx.shadowBlur = 16; ctx.fillStyle = '#69f2d0'; ctx.strokeStyle = '#e6fff8'; ctx.lineWidth = 1.5;
                ctx.beginPath(); ctx.moveTo(0, -25); ctx.lineTo(17, 15); ctx.lineTo(5, 11); ctx.lineTo(0, 17); ctx.lineTo(-5, 11); ctx.lineTo(-17, 15); ctx.closePath(); ctx.fill(); ctx.stroke();
                ctx.fillStyle = '#f5ffff'; ctx.beginPath(); ctx.ellipse(0, -4, 4, 8, 0, 0, Math.PI * 2); ctx.fill();
                ctx.restore();
              };
              const drawTarget = target => {
                ctx.save(); ctx.translate(target.x, target.y); ctx.rotate(target.spin);
                ctx.shadowColor = target.color; ctx.shadowBlur = 18; ctx.fillStyle = target.color; ctx.strokeStyle = '#fff0d2'; ctx.lineWidth = 1.5;
                ctx.beginPath();
                for (let point = 0; point < 8; point++) {
                  const angle = point * Math.PI / 4, radius = point % 2 ? target.radius * .76 : target.radius;
                  const x = Math.cos(angle) * radius, y = Math.sin(angle) * radius;
                  if (point === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                }
                ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.shadowBlur = 0;
                ctx.fillStyle = '#47263b'; ctx.font = `800 ${target.radius * .9}px system-ui`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('×', 0, 1);
                ctx.restore();
              };
              const burst = (x, y, color) => {
                for (let n = 0; n < 8; n++) {
                  const angle = Math.random() * Math.PI * 2, speed = Math.random() * 160 + 45;
                  sparks.push({x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life: .45, color});
                }
              };
              const endGame = () => {
                running = false; dragging = false;
                overlay.querySelector('.gameover-score').textContent = `Score ${score}  ·  Best ${best}`;
                gameOver.hidden = false;
              };
              const resetGame = () => {
                score = 0; lives = 3; spawnTimer = .4; fireTimer = 0; invulnerable = 0;
                bullets = []; targets = []; sparks = []; running = true; lastFrame = gameWindow.performance.now(); gameOver.hidden = true; updateHud();
              };
              overlay.querySelector('.arcade-restart').addEventListener('click', resetGame);
              overlay.querySelector('.arcade-exit').addEventListener('click', closeCredits);
              const frame = now => {
                if (!overlay.isConnected) return;
                const dt = Math.min((now - (lastFrame || now)) / 1000, .04); lastFrame = now;
                const background = ctx.createLinearGradient(0, 0, width, height);
                background.addColorStop(0, '#071a2d'); background.addColorStop(.52, '#0c2637'); background.addColorStop(1, '#18223d');
                ctx.fillStyle = background; ctx.fillRect(0, 0, width, height);
                for (const star of stars) {
                  if (running) star.y = (star.y + star.speed * dt) % height;
                  ctx.globalAlpha = .3 + (Math.sin(now / 450 + star.x) + 1) * .28;
                  ctx.fillStyle = '#b6f8ed'; ctx.fillRect(star.x, star.y, star.size, star.size);
                }
                ctx.globalAlpha = 1;
                const haze = ctx.createRadialGradient(width * .5, height * .57, 5, width * .5, height * .57, Math.max(width, height) * .6);
                haze.addColorStop(0, '#1c938b14'); haze.addColorStop(1, '#06111d00'); ctx.fillStyle = haze; ctx.fillRect(0, 0, width, height);
                if (running) {
                  ship.x += (ship.targetX - ship.x) * Math.min(1, dt * 13); ship.y += (ship.targetY - ship.y) * Math.min(1, dt * 13);
                  invulnerable = Math.max(0, invulnerable - dt);
                  fireTimer -= dt; spawnTimer -= dt;
                  if (fireTimer <= 0) { bullets.push({x: ship.x, y: ship.y - 25}); fireTimer = .16; }
                  if (spawnTimer <= 0) {
                    const radius = 15 + Math.random() * 12;
                    targets.push({x: radius + Math.random() * Math.max(1, width - radius * 2), y: -radius, radius,
                      speed: 105 + Math.random() * 105 + Math.min(score * .3, 130), spin: Math.random() * 6, spinSpeed: (Math.random() - .5) * 2,
                      color: Math.random() > .5 ? '#ff875e' : '#ffc45e'});
                    spawnTimer = Math.max(.28, .92 - score / 850) * (.72 + Math.random() * .55);
                  }
                  bullets.forEach(bullet => bullet.y -= 690 * dt);
                  targets.forEach(target => { target.y += target.speed * dt; target.spin += target.spinSpeed * dt; });
                  for (let bi = bullets.length - 1; bi >= 0; bi--) {
                    const bullet = bullets[bi];
                    const hit = targets.findIndex(target => Math.hypot(target.x - bullet.x, target.y - bullet.y) < target.radius + 5);
                    if (hit >= 0) {
                      const target = targets.splice(hit, 1)[0]; bullets.splice(bi, 1); score += 10; burst(target.x, target.y, target.color); updateHud();
                    }
                  }
                  if (invulnerable <= 0) {
                    const hit = targets.findIndex(target => Math.hypot(target.x - ship.x, target.y - ship.y) < target.radius + 17);
                    if (hit >= 0) {
                      const target = targets.splice(hit, 1)[0]; burst(target.x, target.y, '#ff5f79'); lives -= 1; invulnerable = 1.05; updateHud();
                      if (lives <= 0) endGame();
                    }
                  }
                  const escaped = targets.filter(target => target.y - target.radius > height);
                  if (escaped.length) { targets = targets.filter(target => target.y - target.radius <= height); lives = Math.max(0, lives - 1); updateHud(); if (lives <= 0) endGame(); }
                  bullets = bullets.filter(bullet => bullet.y > -15);
                }
                for (const bullet of bullets) {
                  const trail = ctx.createLinearGradient(bullet.x, bullet.y + 18, bullet.x, bullet.y - 7);
                  trail.addColorStop(0, '#61d9ff00'); trail.addColorStop(1, '#8efcf0'); ctx.strokeStyle = trail; ctx.lineWidth = 3;
                  ctx.shadowColor = '#55f6e0'; ctx.shadowBlur = 12; ctx.beginPath(); ctx.moveTo(bullet.x, bullet.y + 18); ctx.lineTo(bullet.x, bullet.y - 8); ctx.stroke();
                }
                ctx.shadowBlur = 0;
                targets.forEach(drawTarget);
                sparks = sparks.filter(spark => spark.life > 0);
                sparks.forEach(spark => {
                  if (running) { spark.x += spark.vx * dt; spark.y += spark.vy * dt; spark.life -= dt; }
                  ctx.globalAlpha = Math.max(0, spark.life / .45); ctx.fillStyle = spark.color; ctx.fillRect(spark.x, spark.y, 3, 3);
                }); ctx.globalAlpha = 1;
                drawShip(now);
                animationFrame = gameWindow.requestAnimationFrame(frame);
              };
              gameWindow.addEventListener('resize', resize);
              gameWindow.addEventListener('resize', resizeMatrix);
              resizeMatrix(); drawMatrix();
              playButton.addEventListener('click', () => {
                welcome.hidden = true;
                gameScreen.hidden = false;
                resize(); updateHud(); lastFrame = gameWindow.performance.now();
                animationFrame = gameWindow.requestAnimationFrame(frame);
                overlay.querySelector('.credits-close').focus();
              });
              gameCleanup = () => { gameWindow.cancelAnimationFrame(animationFrame); gameWindow.cancelAnimationFrame(matrixFrame); gameWindow.removeEventListener('resize', resize); gameWindow.removeEventListener('resize', resizeMatrix); };
            };
            doc.addEventListener('keydown', event => {
              if (event.key === 'Escape') { closeCredits(); keySequence = ''; return; }
              if (event.ctrlKey || event.metaKey || event.altKey) return;
              const target = event.target;
              if (target?.isContentEditable || /INPUT|TEXTAREA|SELECT/.test(target?.tagName || '')) return;
              keySequence = (keySequence + event.key.toUpperCase()).slice(-4);
              if (keySequence === 'ARYA') {
                keySequence = '';
                event.preventDefault();
                event.stopImmediatePropagation();
                showCredits();
              }
            }, true);
          }
        }
        """,
        isolate_styles=False,
    )


def category_cards_component():
    return st.components.v2.component(
        "patch_dashboard_category_cards",
        html='<div class="category-grid"></div>',
        js="""
        export default function({parentElement, data, setTriggerValue}) {
          const grid = parentElement.querySelector('.category-grid');
          const pendingCategory = grid.dataset.pendingCategory;
          if (pendingCategory && data.cards.some(item => item.key === pendingCategory && item.active)) {
            delete grid.dataset.pendingCategory;
          }
          const visiblePendingCategory = grid.dataset.pendingCategory;
          const activeCategory = visiblePendingCategory || data.cards.find(item => item.active)?.key;
          grid.replaceChildren();
          for (const item of data.cards) {
            const card = document.createElement('button');
            card.type = 'button';
            const active = item.key === activeCategory;
            card.className = 'category-card' + (active ? ' active' : '');
            card.setAttribute('aria-pressed', String(active));
            card.style.setProperty('--pct', item.percentage);
            card.style.setProperty('--ring-color', item.color);
            const ring = document.createElement('span');
            ring.className = 'category-ring';
            const ringText = document.createElement('span');
            ringText.className = 'category-ring-text';
            ringText.textContent = item.percentage + '%';
            ring.append(ringText);
            const copy = document.createElement('span');
            copy.className = 'category-copy';
            const label = document.createElement('span');
            label.className = 'category-label'; label.textContent = item.label;
            const count = document.createElement('span');
            count.className = 'category-count'; count.textContent = item.count.toLocaleString();
            const compliant = document.createElement('span');
            compliant.className = 'category-sub'; compliant.textContent = item.compliant.toLocaleString() + ' compliant';
            copy.append(label, count, compliant);
            card.append(ring, copy);
            card.onclick = () => {
              grid.dataset.pendingCategory = item.key;
              grid.querySelectorAll('.category-card').forEach(other => { other.classList.remove('active'); other.setAttribute('aria-pressed', 'false'); });
              card.classList.add('active');
              card.setAttribute('aria-pressed', 'true');
              setTriggerValue('category_event', {category: item.key, event_id: `${Date.now()}-${Math.random()}`});
            };
            grid.append(card);
          }
        }
        """,
        isolate_styles=False,
    )


def charts_component():
    return st.components.v2.component(
        "patch_dashboard_charts",
        html="""<div class="dashboard-charts">
          <section class="chart-card age-panel"><h3>Patch age distribution</h3><p class="chart-hint"></p><div class="age-bars"><div class="age-bar-columns"></div><div class="age-hover-count" aria-live="polite"></div></div></section>
          <section class="chart-card compliance-panel"><h3>Current-month compliance</h3><p class="chart-hint compliance-hint"></p><div class="donut-hover-count" aria-live="polite"></div>
            <div class="donut-wrap"><svg class="compliance-donut" viewBox="0 0 200 200" role="img" aria-label="Compliance chart">
              <circle class="donut-track" cx="100" cy="100" r="70"></circle><g class="donut-arcs" transform="rotate(-90 100 100)">
              <circle class="donut-bad" cx="100" cy="100" r="70" data-status="Non-compliant"></circle>
              <circle class="donut-good" cx="100" cy="100" r="70" data-status="Compliant"></circle></g>
            </svg><div class="donut-center"><strong class="donut-percent"></strong><span>compliant</span></div></div>
            <div class="donut-legend"><button class="tag tag-good" data-status="Compliant"></button><button class="tag tag-bad" data-status="Non-compliant"></button></div>
          </section>
        </div>""",
        js="""
        export default function({parentElement, data, setTriggerValue}) {
          const root = parentElement.querySelector('.dashboard-charts');
          root.dataset.theme = data.dark ? 'dark' : 'light';
          root.querySelector('.age-panel .chart-hint').textContent = 'Percent of selected servers · cumulative buckets';
          root.querySelector('.compliance-hint').textContent = data.month_hint;
          const bars = root.querySelector('.age-bar-columns'); bars.replaceChildren();
          const barHoverCount = root.querySelector('.age-hover-count');
          for (const item of data.ages) {
            const col = document.createElement('button'); col.type = 'button'; col.className = 'age-bar-column';
            const value = document.createElement('span'); value.className = 'age-bar-value'; value.textContent = item.percentage + '%';
            const track = document.createElement('span'); track.className = 'age-bar-track';
            const bar = document.createElement('span'); bar.className = 'age-bar-fill' + (item.active ? ' active' : '');
            bar.style.height = Math.max(item.bar_height, item.count ? 2 : 0) + '%'; track.append(bar);
            const label = document.createElement('span'); label.className = 'age-bar-label'; label.textContent = item.label;
            col.append(value, track, label);
            col.dataset.active = String(item.active);
            col.onpointerenter = () => { barHoverCount.textContent = `${item.count.toLocaleString()} ${item.count === 1 ? 'server' : 'servers'}`; barHoverCount.classList.add('visible'); };
            col.onpointerleave = () => barHoverCount.classList.remove('visible');
            col.onclick = () => {
              const next = col.dataset.active !== 'true';
              bars.querySelectorAll('.age-bar-column').forEach(other => { other.dataset.active = 'false'; other.querySelector('.age-bar-fill').classList.remove('active'); });
              col.dataset.active = String(next);
              if (next) bar.classList.add('active');
              setTriggerValue('age_event', {filter: item.filter, event_id: `${Date.now()}-${Math.random()}`});
            };
            bars.append(col);
          }
          const total = data.compliant + data.noncompliant;
          const pct = data.compliance_percentage;
          const circumference = 2 * Math.PI * 70;
          const goodLength = total ? circumference * data.compliant / total : 0;
          const badLength = circumference - goodLength;
          const good = root.querySelector('.donut-good'), bad = root.querySelector('.donut-bad');
          good.style.strokeDasharray = `${goodLength} ${circumference - goodLength}`;
          good.style.strokeDashoffset = '0';
          bad.style.strokeDasharray = `${badLength} ${circumference - badLength}`;
          bad.style.strokeDashoffset = `${-goodLength}`;
          root.querySelector('.donut-percent').textContent = pct + '%';
          const hoverCount = root.querySelector('.donut-hover-count');
          for (const [arc, label, count] of [[good, 'Compliant', data.compliant], [bad, 'Non-compliant', data.noncompliant]]) {
            arc.setAttribute('aria-label', `${label}: ${count} servers`);
            arc.onpointerenter = () => { hoverCount.textContent = `${count.toLocaleString()} ${count === 1 ? 'server' : 'servers'}`; hoverCount.classList.add('visible'); };
            arc.onpointerleave = () => hoverCount.classList.remove('visible');
          }
          root.querySelector('[data-status="Compliant"].tag').textContent = `● ${data.compliant.toLocaleString()} Compliant`;
          root.querySelector('[data-status="Non-compliant"].tag').textContent = `● ${data.noncompliant.toLocaleString()} Non-compliant`;
          root.querySelectorAll('[data-status]').forEach(el => {
            el.setAttribute('aria-pressed', String(data.status_filter === el.dataset.status));
            el.onclick = () => {
              const next = el.getAttribute('aria-pressed') !== 'true';
              root.querySelectorAll('[data-status]').forEach(other => other.setAttribute('aria-pressed', 'false'));
              el.setAttribute('aria-pressed', String(next));
              setTriggerValue('status_event', {filter: el.dataset.status, event_id: `${Date.now()}-${Math.random()}`});
            };
          });
        }
        """,
        isolate_styles=False,
    )


def inventory_list_component():
    return st.components.v2.component(
        "patch_dashboard_inventory_list",
        html='<div class="inventory-cards"></div>',
        js="""
        export default function({parentElement, data}) {
          const root = parentElement.querySelector('.inventory-cards'); root.replaceChildren();
          const expandedStorageKey = 'patch-dashboard-expanded-servers';
          let expandedServers = new Set();
          const visibleSetKey = 'patch-dashboard-visible-server-set';
          const visibleSet = JSON.stringify(data.items.map(item => String(item.id)));
          try {
            if (sessionStorage.getItem(visibleSetKey) !== visibleSet) {
              sessionStorage.removeItem(expandedStorageKey);
              sessionStorage.setItem(visibleSetKey, visibleSet);
            }
            expandedServers = new Set(JSON.parse(sessionStorage.getItem(expandedStorageKey) || '[]').map(String));
          } catch (_) {}
          for (const item of data.items) {
            const card = document.createElement('article');
            const serverId = String(item.id);
            const initiallyExpanded = expandedServers.has(serverId);
            card.className = 'server-card' + (initiallyExpanded ? ' expanded' : '');
            const row = document.createElement('div'); row.className = 'server-row-wrap';
            const index = document.createElement('span'); index.className = 'server-index'; index.textContent = item.index;
            const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'copy-host'; copy.setAttribute('aria-label', 'Copy hostname');
            const copyIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"></rect><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"></path></svg>';
            const copiedIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"></path></svg>';
            copy.innerHTML = copyIcon;
            copy.onclick = async event => {
              event.stopPropagation();
              try {
                if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(item.hostname);
                else { const input = document.createElement('textarea'); input.value = item.hostname; input.style.position = 'fixed'; input.style.opacity = '0'; document.body.append(input); input.select(); document.execCommand('copy'); input.remove(); }
                copy.innerHTML = copiedIcon; copy.classList.add('copied'); copy.setAttribute('aria-label', 'Hostname copied');
                setTimeout(() => { copy.innerHTML = copyIcon; copy.classList.remove('copied'); copy.setAttribute('aria-label', 'Copy hostname'); }, 1800);
              } catch (_) { copy.innerHTML = copyIcon; copy.setAttribute('aria-label', 'Could not copy hostname'); }
            };
            const toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = 'server-row-toggle';
            toggle.setAttribute('aria-expanded', String(initiallyExpanded));
            const host = document.createElement('span'); host.className = 'server-host'; host.textContent = item.hostname;
            const category = document.createElement('span'); category.className = `tag tag-${item.category}`; category.textContent = item.category_label;
            const status = document.createElement('span'); status.className = 'tag ' + (item.compliant ? 'tag-good' : 'tag-bad'); status.textContent = item.compliant ? 'Compliant' : 'Non-compliant';
            const arrow = document.createElement('span'); arrow.className = 'server-chevron'; arrow.textContent = '›';
            toggle.append(host, category, status, arrow);
            toggle.onclick = () => {
              const expanded = card.classList.toggle('expanded');
              toggle.setAttribute('aria-expanded', String(expanded));
              if (expanded) expandedServers.add(serverId);
              else expandedServers.delete(serverId);
              try { sessionStorage.setItem(expandedStorageKey, JSON.stringify([...expandedServers])); } catch (_) {}
            };
            row.append(index, copy, toggle);
            card.append(row);
            const detail = document.createElement('div'); detail.className = 'server-detail';
            const top = document.createElement('div'); top.className = 'server-detail-top';
            const facts = document.createElement('div'); facts.className = 'server-facts';
            for (const [labelText, valueText, tone] of [
              ['Last patch', item.patch_date, 'patch'], ['Age', `${item.age} days`, 'age'], ['Last reported', item.last_report_date, 'reported']
            ]) {
              const fact = document.createElement('div'); fact.className = `server-fact fact-${tone}`;
              const label = document.createElement('span'); label.className = 'fact-label'; label.textContent = labelText;
              const value = document.createElement('strong'); value.className = 'fact-value'; value.textContent = valueText;
              fact.append(label, value); facts.append(fact);
            }
            top.append(facts);
            const historyHead = document.createElement('div'); historyHead.className = 'server-history-heading';
            const historyTitle = document.createElement('strong'); historyTitle.textContent = 'Patch history';
            historyHead.append(historyTitle);
            const history = document.createElement('div'); history.className = 'server-history';
            if (item.history.length) item.history.forEach(day => { const entry = document.createElement('div'); entry.textContent = '• ' + day; history.append(entry); });
            else history.textContent = 'No patch history is recorded yet.';
            detail.append(top, historyHead, history);
            card.append(detail);
            root.append(card);
          }
        }
        """,
        isolate_styles=False,
    )


def get_connection():
    if not DB_PATH.exists():
        create_database()
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@st.cache_data(ttl=5, show_spinner=False)
def load_inventory():
    conn = get_connection()
    try:
        return conn.execute(
            """SELECT s.id, s.hostname, s.category_key, s.last_patch_date,
                      s.ip_address, s.last_report_date
               FROM servers s
               ORDER BY CASE s.category_key
                          WHEN 'production' THEN 0
                          WHEN 'non_production' THEN 1
                          WHEN 'cloud' THEN 2
                          ELSE 3 END,
                        s.hostname COLLATE NOCASE"""
        ).fetchall()
    finally:
        conn.close()


@st.cache_data(ttl=5, show_spinner=False)
def load_latest_reports():
    conn = get_connection()
    try:
        return conn.execute(
            """SELECT category_key, MAX(report_date)
               FROM reports WHERE is_current = 1 GROUP BY category_key"""
        ).fetchall()
    finally:
        conn.close()


@st.cache_data(ttl=5, show_spinner=False)
def load_history(server_id):
    conn = get_connection()
    try:
        return conn.execute(
            """SELECT patch_date FROM patch_history WHERE server_id = ?
               ORDER BY patch_date DESC""",
            (server_id,),
        ).fetchall()
    finally:
        conn.close()


def is_compliant(patch_date, today):
    parsed = date.fromisoformat(patch_date)
    return parsed.year == today.year and parsed.month == today.month


def age_days(patch_date, today):
    return max(0, (today - date.fromisoformat(patch_date)).days)


def percentage_floor(numerator, denominator):
    """Show a conservative whole-number percentage without overstating rates."""
    return (numerator * 100) // denominator if denominator else 0


def fuzzy_matches(query, *values):
    query = query.casefold().strip()
    if not query:
        return True
    for value in values:
        if not value:
            continue
        candidate = str(value).casefold()
        if query in candidate or SequenceMatcher(None, query, candidate).ratio() >= 0.85:
            return True
        host_label = candidate.split(".", 1)[0]
        if len(query) >= 4 and SequenceMatcher(None, query, host_label).ratio() >= 0.85:
            return True
    return False


def passes_age(age, selected):
    if selected == "30 days or less":
        return age <= 30
    if selected == "60 days or less":
        return age <= 60
    if selected == "90 days or less":
        return age <= 90
    if selected == "More than 90 days":
        return age > 90
    return True


def scroll_component():
    component = st.components.v2.component(
        "patch_dashboard_scroll_and_top",
        html="",
        js="""
        export default function({parentElement, data}) {
          let win = window;
          let doc = document;
          try {
            if (window.parent && window.parent !== window && window.parent.document) {
              win = window.parent;
              doc = window.parent.document;
            }
          } catch (error) { /* Use this component's document if parent access is unavailable. */ }
          const stateKey = '__patchDashboardScrollState';
          const state = win[stateKey] || (win[stateKey] = {token: '0'});
          const token = String(data?.scroll_token ?? 0);
          const categoryToken = String(data?.category_scroll_token ?? 0);
          const shouldScrollInventory = state.inventoryToken !== token && Number(token) > 0;
          const shouldScrollCategory = state.categoryToken !== categoryToken && Number(categoryToken) > 0;
          state.inventoryToken = token;
          state.categoryToken = categoryToken;
          if (shouldScrollCategory) {
            const target = doc.getElementById('category-cards');
            if (target) setTimeout(() => target.scrollIntoView({behavior:'smooth', block:'start'}), 100);
          } else if (shouldScrollInventory) {
            const target = doc.getElementById('server-inventory');
            if (target) setTimeout(() => target.scrollIntoView({behavior:'smooth', block:'start'}), 100);
          }
        }
        """,
    )
    return component


def reset_filters():
    st.session_state.age_filter = "All"
    st.session_state.status_filter = "All"
    st.session_state.category_filter = "All"
    st.session_state.search = ""
    st.session_state.age_filter_widget = "All"
    st.session_state.status_filter_widget = "All"
    st.session_state.category_filter_widget = "All"
    st.session_state.inventory_search = ""


def main():
    st.session_state.setdefault("dark_mode", False)
    st.session_state.setdefault("category", "all")
    st.session_state.setdefault("age_filter", "All")
    st.session_state.setdefault("status_filter", "All")
    st.session_state.setdefault("search", "")
    st.session_state.setdefault("category_filter", "All")
    st.session_state.setdefault("scroll_token", 0)
    st.session_state.setdefault("category_scroll_token", 0)

    inventory = load_inventory()
    latest_reports = dict(load_latest_reports())
    today = date.today()
    header = dashboard_header_component()(data={
        "dark": st.session_state.dark_mode,
        "subtitle": f"Live cumulative inventory · Compliance for {today.strftime('%B %Y')} · Last updated {max(latest_reports.values()) if latest_reports else '—'}",
    }, key="patch_dashboard_header")
    theme_event = header.get("theme_event")
    if (
        isinstance(theme_event, dict)
        and theme_event.get("event_id") != st.session_state.get("last_theme_event_id")
    ):
        st.session_state.dark_mode = bool(theme_event.get("dark_mode"))
        st.session_state.last_theme_event_id = theme_event.get("event_id")
    inject_css()
    st.markdown('<div id="dashboard-top"></div>', unsafe_allow_html=True)

    if not inventory:
        st.info("Place a valid simulation-format JSON report in data/incoming/ and start processor/watcher.py.")
        return

    rows = [
        {
            "id": row[0], "hostname": row[1], "category": row[2],
            "patch_date": row[3], "ip_address": row[4], "last_report_date": row[5],
            "age": age_days(row[3], today), "compliant": is_compliant(row[3], today),
        }
        for row in inventory
    ]
    category_cards = []
    for key, title, _display in CATEGORIES:
        category_rows = rows if key == "all" else [row for row in rows if row["category"] == key]
        compliant = sum(row["compliant"] for row in category_rows)
        count = len(category_rows)
        category_cards.append({
            "key": key, "label": title, "count": count, "compliant": compliant,
            "percentage": percentage_floor(compliant, count),
            "active": st.session_state.category == key,
            "color": {"all": "#5b3df0", "non_production": "#0d9488", "production": "#db2777", "cloud": "#d97706"}[key],
        })
    st.markdown('<div id="category-cards"></div>', unsafe_allow_html=True)
    category_event = category_cards_component()(data={"cards": category_cards}, key="patch_category_cards")
    category_click = category_event.get("category_event")
    requested_category = category_click.get("category") if isinstance(category_click, dict) else None
    category_event_id = category_click.get("event_id") if isinstance(category_click, dict) else None
    if (
        requested_category in {key for key, _, _ in CATEGORIES}
        and category_event_id != st.session_state.get("last_category_event_id")
    ):
        st.session_state.last_category_event_id = category_event_id
        st.session_state.category = requested_category
        st.session_state.category_scroll_token += 1
        st.session_state.age_filter = "All"
        st.session_state.status_filter = "All"
        st.session_state.category_filter = "All"
        st.session_state.age_filter_widget = "All"
        st.session_state.status_filter_widget = "All"
        st.session_state.category_filter_widget = "All"
        st.session_state.search = ""
        st.session_state.inventory_search = ""

    selected_category = st.session_state.category
    selected_name = next(title for key, title, _ in CATEGORIES if key == selected_category)
    base_rows = [r for r in rows if selected_category == "all" or r["category"] == selected_category]
    st.markdown(f'<h2 class="section-heading">{html.escape(selected_name)}</h2>', unsafe_allow_html=True)
    st.markdown('<p class="section-caption">Patch age is measured from today. Click a column or ring segment to filter the inventory below.</p>', unsafe_allow_html=True)

    denominator = len(base_rows)
    age_buckets = [
        ("≤30 days", lambda n: n <= 30, "30 days or less"),
        ("≤60 days", lambda n: n <= 60, "60 days or less"),
        ("≤90 days", lambda n: n <= 90, "90 days or less"),
        (">90 days", lambda n: n > 90, "More than 90 days"),
    ]
    age_values = []
    for label, predicate, filter_label in age_buckets:
        count = sum(predicate(r["age"]) for r in base_rows)
        age_values.append({
            "label": label,
            "filter": filter_label,
            "count": count,
            "percentage": percentage_floor(count, denominator),
            "bar_height": count * 100 / denominator if denominator else 0,
            "active": st.session_state.age_filter == filter_label,
        })
    compliant_count = sum(row["compliant"] for row in base_rows)
    chart_event = charts_component()(data={
        "dark": st.session_state.dark_mode,
        "ages": age_values,
        "status_filter": st.session_state.status_filter,
        "compliant": compliant_count,
        "noncompliant": denominator - compliant_count,
        "compliance_percentage": percentage_floor(compliant_count, denominator),
        "month_hint": f"Compliant when last patched during {today.strftime('%B %Y')}.",
    }, key="patch_dashboard_charts")
    age_click = chart_event.get("age_event")
    selected_age = age_click.get("filter") if isinstance(age_click, dict) else None
    age_event_id = age_click.get("event_id") if isinstance(age_click, dict) else None
    if selected_age in AGE_OPTIONS and age_event_id != st.session_state.get("last_age_event_id"):
        st.session_state.last_age_event_id = age_event_id
        st.session_state.age_filter = "All" if st.session_state.age_filter == selected_age else selected_age
        st.session_state.age_filter_widget = st.session_state.age_filter
        st.session_state.scroll_token += 1
    status_click = chart_event.get("status_event")
    selected_status = status_click.get("filter") if isinstance(status_click, dict) else None
    status_event_id = status_click.get("event_id") if isinstance(status_click, dict) else None
    if selected_status in STATUS_OPTIONS and status_event_id != st.session_state.get("last_status_event_id"):
        st.session_state.last_status_event_id = status_event_id
        st.session_state.status_filter = "All" if st.session_state.status_filter == selected_status else selected_status
        st.session_state.status_filter_widget = st.session_state.status_filter
        st.session_state.scroll_token += 1

    st.markdown('<div id="server-inventory"></div>', unsafe_allow_html=True)
    scroll_component()(data={
        "scroll_token": st.session_state.scroll_token,
        "category_scroll_token": st.session_state.category_scroll_token,
    }, key="scroll_controls")
    st.markdown('<h2 class="inventory-title">Server inventory</h2>', unsafe_allow_html=True)

    f1, f2, f3, f4 = st.columns([2.1, 1, 1, 1.1], gap="medium")
    with f1:
        search = st.text_input("Search hostname or IP", key="inventory_search", placeholder="Search hostname or IP")
        st.session_state.search = search
    with f2:
        st.session_state.age_filter = st.selectbox(
            "Patch age", AGE_OPTIONS, index=AGE_OPTIONS.index(st.session_state.age_filter), key="age_filter_widget"
        )
    with f3:
        st.session_state.status_filter = st.selectbox(
            "Compliance", STATUS_OPTIONS, index=STATUS_OPTIONS.index(st.session_state.status_filter), key="status_filter_widget"
        )
    with f4:
        if selected_category == "all":
            category_labels = ["All"] + [display for _, _, display in CATEGORIES[1:]]
            st.session_state.category_filter = st.selectbox(
                "Category", category_labels,
                index=category_labels.index(st.session_state.category_filter), key="category_filter_widget",
            )
        else:
            st.selectbox("Category", [selected_name], index=0, disabled=True, key="category_fixed_widget")

    active_filters = []
    if st.session_state.search.strip():
        active_filters.append(f"Search: {st.session_state.search.strip()}")
    if st.session_state.age_filter != "All":
        active_filters.append(f"Age: {st.session_state.age_filter}")
    if st.session_state.status_filter != "All":
        active_filters.append(f"Status: {st.session_state.status_filter}")
    if selected_category == "all" and st.session_state.category_filter != "All":
        active_filters.append(f"Category: {st.session_state.category_filter}")
    if active_filters:
        left, right = st.columns([5, 1])
        with left:
            st.markdown(f'<div class="active-filter">Active filters: {html.escape(" · ".join(active_filters))}</div>', unsafe_allow_html=True)
        with right:
            st.button("Reset filters", key="reset_filters", use_container_width=True, on_click=reset_filters)

    candidates = []
    query = st.session_state.search.strip().casefold()
    for row in base_rows:
        if not passes_age(row["age"], st.session_state.age_filter):
            continue
        if st.session_state.status_filter == "Compliant" and not row["compliant"]:
            continue
        if st.session_state.status_filter == "Non-compliant" and row["compliant"]:
            continue
        if selected_category == "all" and st.session_state.category_filter != "All":
            normalized = st.session_state.category_filter.casefold().replace("-", "_")
            if row["category"] != normalized:
                continue
        candidates.append(row)

    if query:
        direct_matches = [
            row for row in candidates
            if query in row["hostname"].casefold()
            or query in (row["ip_address"] or "").casefold()
        ]
        filtered = direct_matches or [
            row for row in candidates
            if fuzzy_matches(query, row["hostname"], row["ip_address"])
        ]
    else:
        filtered = candidates

    st.markdown(f'<p class="server-list-caption">Showing {len(filtered):,} of {len(base_rows):,} known servers</p>', unsafe_allow_html=True)
    if not filtered:
        st.info("No servers match the current filters.")
    else:
        category_labels = {key: display for key, _, display in CATEGORIES[1:]}
        inventory_items = []
        for index, row in enumerate(filtered, start=1):
            history = [entry[0] for entry in load_history(row["id"])]
            inventory_items.append({
                "id": row["id"], "index": index, "hostname": row["hostname"],
                "category": row["category"], "category_label": category_labels[row["category"]],
                "compliant": row["compliant"],
                "patch_date": row["patch_date"], "age": row["age"],
                "last_report_date": row["last_report_date"], "history": history,
            })
        inventory_list_component()(data={"items": inventory_items}, key="patch_inventory_list")

    st.markdown("---")
    st.caption("Patch Compliance Dashboard · Data refreshes every 10 seconds · Missing servers remain in the known inventory.")


main()
