"""Regression coverage for archive retries with legacy source_file paths."""

import logging
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

# Prevent importing the watcher from configuring the project log file.
logging.basicConfig(handlers=[logging.NullHandler()])

import database.init_db as init_db
import processor.process_reports as process_reports
import processor.watcher as watcher


class LegacySourcePathArchiveRetryTest(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(prefix="patch-dashboard-retry-")
        self.root = Path(self.temp_dir.name)
        self.db_path = self.root / "test.sqlite"

        self.original_init_db_path = init_db.DB_PATH
        self.original_processor_db_path = process_reports.DB_PATH
        self.original_watcher_paths = (
            watcher.BASE_DIR,
            watcher.INCOMING_DIR,
            watcher.ARCHIVE_DIR,
            watcher.ERROR_DIR,
            watcher.DUPLICATE_DIR,
        )

        init_db.DB_PATH = self.db_path
        process_reports.DB_PATH = self.db_path
        watcher.BASE_DIR = self.root
        watcher.INCOMING_DIR = self.root / "incoming"
        watcher.ARCHIVE_DIR = self.root / "archive"
        watcher.ERROR_DIR = self.root / "error"
        watcher.DUPLICATE_DIR = self.root / "duplicates"
        for directory in (
            watcher.INCOMING_DIR,
            watcher.ARCHIVE_DIR,
            watcher.ERROR_DIR,
            watcher.DUPLICATE_DIR,
        ):
            directory.mkdir(parents=True)

        self.original_logger = watcher.logger
        watcher.logger = logging.getLogger("legacy-source-path-test")
        watcher.logger.handlers = [logging.NullHandler()]
        watcher.logger.propagate = False
        init_db.create_database(reset=True)

    def tearDown(self):
        watcher.logger = self.original_logger
        (
            watcher.BASE_DIR,
            watcher.INCOMING_DIR,
            watcher.ARCHIVE_DIR,
            watcher.ERROR_DIR,
            watcher.DUPLICATE_DIR,
        ) = self.original_watcher_paths
        process_reports.DB_PATH = self.original_processor_db_path
        init_db.DB_PATH = self.original_init_db_path
        self.temp_dir.cleanup()

    def _counts(self):
        with sqlite3.connect(self.db_path) as connection:
            return tuple(
                connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                for table in ("reports", "report_servers", "servers", "patch_history")
            )

    def test_legacy_absolute_source_path_retries_to_archive(self):
        filename = "Production_2026-08-24.json"
        payload = {
            "category": "production",
            "report_date": "2026-08-24",
            "servers": [
                {"hostname": "prod-retry-01.example", "last_patch_date": "2026-08-20"}
            ],
        }
        original_source = self.root / "original" / filename
        original_source.parent.mkdir()
        original_source.write_text(json.dumps(payload), encoding="utf-8")
        self.assertEqual(process_reports.process_report(original_source), "PROCESSED")

        retry_path = watcher.INCOMING_DIR / filename
        retry_path.write_text(json.dumps(payload), encoding="utf-8")
        self.assertTrue(process_reports.was_processed_from_source(retry_path))

        legacy_path = f"/home/Xlaper/patch-dashboard/data/incoming/{filename}"
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                "UPDATE reports SET source_file = ? WHERE report_date = ?",
                (legacy_path, payload["report_date"]),
            )

        self.assertTrue(process_reports.was_processed_from_source(retry_path))
        before_retry = self._counts()

        with mock.patch.object(watcher, "wait_until_stable"):
            result = watcher.handle_file(retry_path)

        archived_retry = watcher.ARCHIVE_DIR / payload["report_date"] / filename
        self.assertEqual(result, "DUPLICATE")
        self.assertTrue(archived_retry.exists())
        self.assertFalse(retry_path.exists())
        self.assertEqual(self._counts(), before_retry)

        # A matching duplicate with a different filename remains a duplicate.
        genuine_duplicate = watcher.INCOMING_DIR / "copied-report.json"
        genuine_duplicate.write_text(json.dumps(payload), encoding="utf-8")
        with mock.patch.object(watcher, "wait_until_stable"):
            duplicate_result = watcher.handle_file(genuine_duplicate)
        duplicate_path = watcher.DUPLICATE_DIR / payload["report_date"] / genuine_duplicate.name
        self.assertEqual(duplicate_result, "DUPLICATE")
        self.assertTrue(duplicate_path.exists())
        self.assertEqual(self._counts(), before_retry)

        # A genuinely new report still commits and is archived as normal.
        new_payload = {
            "category": "production",
            "report_date": "2026-08-25",
            "servers": [
                {"hostname": "prod-new-01.example", "last_patch_date": "2026-08-25"}
            ],
        }
        new_report = watcher.INCOMING_DIR / "Production_2026-08-25.json"
        new_report.write_text(json.dumps(new_payload), encoding="utf-8")
        with mock.patch.object(watcher, "wait_until_stable"):
            new_result = watcher.handle_file(new_report)

        self.assertEqual(new_result, "PROCESSED")
        self.assertTrue(
            (watcher.ARCHIVE_DIR / new_payload["report_date"] / new_report.name).exists()
        )
        self.assertEqual(self._counts(), (2, 2, 2, 2))


if __name__ == "__main__":
    unittest.main()
