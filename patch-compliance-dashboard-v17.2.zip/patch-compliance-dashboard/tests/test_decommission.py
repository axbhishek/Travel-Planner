"""Temporary-database tests for manual server decommissioning."""

import json
import sqlite3
import sys
import tempfile
import unittest
from datetime import date
from io import StringIO
from pathlib import Path
from unittest import mock

import database.decommission as decommission
import database.init_db as init_db
import processor.process_reports as process_reports


class DecommissionTest(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(prefix="patch-dashboard-decommission-")
        self.root = Path(self.temp_dir.name)
        self.db_path = self.root / "patch_dashboard.db"
        self.backup_dir = self.root / "backups"
        self.original_init_path = init_db.DB_PATH
        self.original_processor_path = process_reports.DB_PATH
        init_db.DB_PATH = self.db_path
        process_reports.DB_PATH = self.db_path
        init_db.create_database(reset=True)

    def tearDown(self):
        process_reports.DB_PATH = self.original_processor_path
        init_db.DB_PATH = self.original_init_path
        self.temp_dir.cleanup()

    def _report(self, category, report_date, servers):
        path = self.root / f"{category}_{report_date}.json"
        path.write_text(json.dumps({
            "category": category,
            "report_date": report_date,
            "servers": servers,
        }), encoding="utf-8")
        return process_reports.process_report(path)

    def _seed(self):
        self._report("production", "2026-09-20", [
            {"hostname": "prod-delete", "last_patch_date": "2026-09-20"},
            {"hostname": "prod-keep", "last_patch_date": "2026-08-01"},
        ])
        self._report("production", "2026-10-01", [
            {"hostname": "prod-delete", "last_patch_date": "2026-10-01"},
            {"hostname": "prod-keep", "last_patch_date": "2026-08-01"},
        ])
        self._report("non_production", "2026-10-01", [
            {"hostname": "np-delete", "last_patch_date": "2026-10-01"},
            {"hostname": "np-keep", "last_patch_date": "2026-08-01"},
        ])
        self._report("cloud", "2026-10-01", [
            {"hostname": "cloud-delete", "last_patch_date": "2026-10-01"},
            {"hostname": "cloud-keep", "last_patch_date": "2026-08-01"},
        ])

    def _run(self, hostnames):
        return decommission.decommission_servers(
            hostnames, db_path=self.db_path, backup_dir=self.backup_dir
        )

    def _scalar(self, sql, params=()):
        with sqlite3.connect(self.db_path) as connection:
            return connection.execute(sql, params).fetchone()[0]

    def _dashboard_rows(self):
        # Same active-inventory columns used by app/dashboard.py's load query.
        with sqlite3.connect(self.db_path) as connection:
            return connection.execute(
                """SELECT s.id, s.hostname, s.category_key, s.last_patch_date,
                          s.ip_address, s.last_report_date
                   FROM servers s
                   ORDER BY CASE s.category_key WHEN 'production' THEN 0
                     WHEN 'non_production' THEN 1 WHEN 'cloud' THEN 2 ELSE 3 END,
                     s.hostname COLLATE NOCASE"""
            ).fetchall()

    def _metrics(self, rows, category=None):
        today = date(2026, 10, 1)
        selected = [row for row in rows if category is None or row[2] == category]
        ages = [(today - date.fromisoformat(row[3])).days for row in selected]
        compliant = sum(date.fromisoformat(row[3]).month == today.month for row in selected)
        return {
            "total": len(selected), "compliant": compliant,
            "noncompliant": len(selected) - compliant,
            "le30": sum(age <= 30 for age in ages),
            "le60": sum(age <= 60 for age in ages),
            "le90": sum(age <= 90 for age in ages),
            "gt90": sum(age > 90 for age in ages),
        }

    def test_removes_servers_across_all_categories_and_preserves_other_snapshot_rows(self):
        self._seed()
        before_reports = self._scalar("SELECT COUNT(*) FROM reports")
        result = self._run(["PROD-DELETE", "np-delete", "cloud-delete", "missing-host"])

        self.assertEqual(set(result["removed"]), {"prod-delete", "np-delete", "cloud-delete"})
        self.assertEqual(result["not_found"], ["missing-host"])
        self.assertTrue(Path(result["backup"]).is_file())
        for name in ("prod-delete", "np-delete", "cloud-delete"):
            self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers WHERE hostname_key = ?", (name,)), 0)
            self.assertEqual(self._scalar("SELECT COUNT(*) FROM report_servers WHERE hostname_key = ?", (name,)), 0)
            self.assertEqual(self._scalar(
                "SELECT COUNT(*) FROM patch_history h JOIN servers s ON s.id=h.server_id WHERE s.hostname_key = ?",
                (name,),
            ), 0)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers"), 3)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM reports"), before_reports)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM report_servers"), 4)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM patch_history"), 3)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers WHERE category_key='production'"), 1)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers WHERE category_key='non_production'"), 1)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers WHERE category_key='cloud'"), 1)
        with sqlite3.connect(self.db_path) as connection:
            self.assertEqual(connection.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(connection.execute("PRAGMA foreign_key_check").fetchall(), [])
            self.assertEqual(connection.execute(
                "SELECT COUNT(*) FROM report_servers rs LEFT JOIN servers s ON s.id=rs.server_id WHERE s.id IS NULL"
            ).fetchone()[0], 0)
            self.assertEqual(connection.execute(
                "SELECT COUNT(*) FROM patch_history h LEFT JOIN servers s ON s.id=h.server_id WHERE s.id IS NULL"
            ).fetchone()[0], 0)

    def test_missing_and_repeated_decommission_are_safe_and_case_insensitive(self):
        self._seed()
        first = self._run(["PROD-KEEP"])
        self.assertEqual(first["removed"], ["prod-keep"])
        second = self._run(["prod-keep", "PROD-KEEP", "server99"])
        self.assertEqual(second["removed"], [])
        self.assertEqual(second["not_found"], ["prod-keep", "server99"])
        self.assertIsNone(second["backup"])

    def test_project_maintenance_command_reports_removed_names_and_backup(self):
        self._seed()
        output = StringIO()
        with mock.patch.object(decommission, "DB_PATH", self.db_path), \
             mock.patch.object(sys, "stdout", output):
            exit_code = decommission.main(["PROD-DELETE", "unknown-host"])
        self.assertEqual(exit_code, 0)
        self.assertIn("Removed:\n  prod-delete", output.getvalue())
        self.assertIn("Not found:\n  unknown-host", output.getvalue())
        self.assertIn("Backup:", output.getvalue())
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers WHERE hostname_key='prod-delete'"), 0)

    def test_deleted_server_reappears_as_new_with_fresh_history(self):
        self._seed()
        self._run(["prod-delete"])
        self._report("production", "2026-10-15", [
            {"hostname": "prod-delete", "last_patch_date": "2026-10-15"},
            {"hostname": "prod-keep", "last_patch_date": "2026-08-01"},
        ])
        with sqlite3.connect(self.db_path) as connection:
            row = connection.execute(
                "SELECT id, last_patch_date FROM servers WHERE hostname_key='prod-delete'"
            ).fetchone()
            self.assertIsNotNone(row)
            self.assertEqual(row[1], "2026-10-15")
            history = connection.execute(
                "SELECT patch_date FROM patch_history WHERE server_id=? ORDER BY patch_date",
                (row[0],),
            ).fetchall()
            self.assertEqual(history, [("2026-10-15",)])
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM servers").fetchone()[0], 6)

    def test_snapshot_absence_does_not_delete_inventory(self):
        self._seed()
        self._report("production", "2026-10-02", [
            {"hostname": "prod-keep", "last_patch_date": "2026-08-01"},
        ])
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers WHERE hostname_key='prod-delete'"), 1)

    def test_dashboard_inventory_and_derived_metrics_exclude_removed_server(self):
        self._seed()
        before_rows = self._dashboard_rows()
        self.assertIn("prod-delete", [row[1] for row in before_rows])
        self.assertEqual(self._metrics(before_rows), {
            "total": 6, "compliant": 3, "noncompliant": 3,
            "le30": 3, "le60": 3, "le90": 6, "gt90": 0,
        })
        self.assertEqual(self._metrics(before_rows, "production")["total"], 2)

        self._run(["prod-delete"])
        after_rows = self._dashboard_rows()
        self.assertNotIn("prod-delete", [row[1] for row in after_rows])
        self.assertEqual(self._metrics(after_rows), {
            "total": 5, "compliant": 2, "noncompliant": 3,
            "le30": 2, "le60": 2, "le90": 5, "gt90": 0,
        })
        self.assertEqual(self._metrics(after_rows, "production"), {
            "total": 1, "compliant": 0, "noncompliant": 1,
            "le30": 0, "le60": 0, "le90": 1, "gt90": 0,
        })

    def test_failure_rolls_back_all_deletions(self):
        self._seed()
        before = tuple(self._scalar(f"SELECT COUNT(*) FROM {table}") for table in
                       ("reports", "servers", "report_servers", "patch_history"))

        def fail_after_snapshot_delete(connection, server_id):
            connection.execute("DELETE FROM report_servers WHERE server_id = ?", (server_id,))
            raise RuntimeError("simulated failure")

        with mock.patch.object(decommission, "_delete_server_records", side_effect=fail_after_snapshot_delete):
            with self.assertRaisesRegex(RuntimeError, "simulated failure"):
                self._run(["prod-delete"])
        after = tuple(self._scalar(f"SELECT COUNT(*) FROM {table}") for table in
                      ("reports", "servers", "report_servers", "patch_history"))
        self.assertEqual(after, before)
        self.assertEqual(self._scalar("SELECT COUNT(*) FROM servers WHERE hostname_key='prod-delete'"), 1)

    def test_duplicate_and_revision_processing_remain_compatible(self):
        self._seed()
        unchanged = self._report("production", "2026-10-15", [
            {"hostname": "prod-keep", "last_patch_date": "2026-08-01"},
        ])
        duplicate = self._report("production", "2026-10-15", [
            {"hostname": "prod-keep", "last_patch_date": "2026-08-01"},
        ])
        self.assertEqual(unchanged, "PROCESSED")
        self.assertEqual(duplicate, "DUPLICATE")
        correction_path = self.root / "production_correction.json"
        correction_path.write_text(json.dumps({
            "category": "production", "report_date": "2026-10-15",
            "servers": [{"hostname": "prod-keep", "last_patch_date": "2026-10-15"}],
        }), encoding="utf-8")
        self.assertEqual(process_reports.process_report(correction_path), "CORRECTION")


if __name__ == "__main__":
    unittest.main()
