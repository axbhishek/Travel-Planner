"""Create the local environment, then run the report watcher and dashboard."""

import subprocess
import sys
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parent
VENV_DIR = PROJECT_DIR / ".venv"


def main():
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 or newer is required.")

    if sys.platform == "win32":
        python = VENV_DIR / "Scripts" / "python.exe"
    else:
        python = VENV_DIR / "bin" / "python"

    if not python.exists():
        subprocess.run([sys.executable, "-m", "venv", str(VENV_DIR)], check=True)

    dependencies = subprocess.run(
        [str(python), "-c", "import streamlit, streamlit_autorefresh, watchdog"],
        cwd=PROJECT_DIR,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    if dependencies.returncode:
        subprocess.run(
            [str(python), "-m", "pip", "install", "-r", str(PROJECT_DIR / "requirements.txt")],
            cwd=PROJECT_DIR,
            check=True,
        )

    watcher = subprocess.Popen(
        [str(python), str(PROJECT_DIR / "processor" / "watcher.py")],
        cwd=PROJECT_DIR,
    )
    try:
        subprocess.run(
            [str(python), "-m", "streamlit", "run", str(PROJECT_DIR / "app" / "dashboard.py")],
            cwd=PROJECT_DIR,
            check=False,
        )
    except KeyboardInterrupt:
        pass
    finally:
        watcher.terminate()
        try:
            watcher.wait(timeout=5)
        except subprocess.TimeoutExpired:
            watcher.kill()
            watcher.wait()


if __name__ == "__main__":
    main()
