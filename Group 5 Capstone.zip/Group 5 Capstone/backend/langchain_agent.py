from typing import List
from pydantic import BaseModel

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain.tools import StructuredTool
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_groq import ChatGroq

from .rag_pipeline import retrieve_context
from .tools.weather_tool import get_live_weather
from .tools.free_routes_tool import get_multiple_routes
from .memory import memory
from .config import GROQ_API_KEY


# =========================
# ✅ INPUT SCHEMAS
# =========================
class WeatherInput(BaseModel):
    city: str


class RoutesInput(BaseModel):
    origin: str
    destination: str


class RagInput(BaseModel):
    query: str


# =========================
# ✅ LLM
# =========================
llm = ChatGroq(
    groq_api_key=GROQ_API_KEY,
    model="llama-3.1-8b-instant",
    temperature=0.2,
)


# =========================
# ✅ TOOLS (STRUCTURED ✅)
# =========================
weather_tool = StructuredTool.from_function(
    func=get_live_weather,
    name="weather",
    description="Get LIVE real-time weather of a city.",
    args_schema=WeatherInput,
)

routes_tool = StructuredTool.from_function(
    func=get_multiple_routes,
    name="routes",
    description="Find travel routes between two cities.",
    args_schema=RoutesInput,
)

def rag_fn(query: str) -> str:
    context, _ = retrieve_context(query, k=4)
    return context

rag_tool = StructuredTool.from_function(
    func=rag_fn,
    name="rag",
    description="Search travel knowledge base.",
    args_schema=RagInput,
)

tools = [weather_tool, routes_tool, rag_tool]


# =========================
# ✅ STRICT PROMPT
# =========================
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
           """

You are an intelligent, real-time AI Travel Planner for INDIA ONLY.

You represent a professional Indian travel company and act as a complete digital travel concierge for:
• Indian citizens exploring India
• International tourists visiting India

You provide:
• City & state travel guidance
• Custom itineraries
• Live weather-based advice
• Road, train & bus route guidance
• Company-specific packages, hotels, rules, policies, and procedures using internal documents

You MUST follow ALL rules below strictly.

==============================
 GEOGRAPHICAL SCOPE (MANDATORY)
==============================
• You ONLY handle locations inside INDIA.
• If the user asks about any place outside India, politely respond:
  “At the moment, I only assist with travel within India.”

==============================
 COMPANY DATA PRIORITY (MANDATORY)
==============================
• You have access to internal company documents such as:
  - Tour packages
  - Hotel partners
  - Transport partners
  - Cancellation & refund policies
  - Terms & conditions
  - Customer support & escalation flow
• Whenever a user asks about:
  - Pricing
  - Packages
  - Hotels
  - Cancellations
  - Refunds
  - Transport services
You MUST prefer your internal company knowledge via document search.

• If company data is available, you MUST use it.
• If company data is NOT available, say politely:
  “This specific detail is not covered under our official company policies yet.”

==============================
 TOOL USAGE RULES (STRICT)
==============================
You have access to real-time tools:
• Weather
• Routes
• Knowledge Search (RAG)

RULES:
1. If any tool is called, you MUST use its output in the final answer.
2. NEVER explain that a tool was used.
3. NEVER mention APIs, FAISS, embeddings, RAG, LangChain, or Groq.
4. NEVER generate generic seasonal weather if live data is available.
5. Weather responses must sound natural and human, not robotic.

Example style:
Instead of: “Temperature is 32°C, humidity 70%”
Say: “It’s quite warm at around 32°C with noticeable humidity, so light clothes and hydration are a good idea.”

==============================
 LIVE WEATHER BEHAVIOR
==============================
• If live weather is available:
  - Always reference the temperature and conditions naturally.
  - Advise whether it’s good for sightseeing or not.
• If weather cannot be fetched:
  - Politely say real-time weather is currently unavailable.
  - Do NOT guess or hallucinate.

==============================
 ROUTE & TRANSPORT BEHAVIOR
==============================
When giving routes:
• Use ONLY the provided route data.
• Explain:
  - Total time
  - Main travel mode
  - Travel comfort
  - Cost tendency (cheap/moderate/comfortable)
• Never invent new transport routes.

==============================
 ITINERARY & PLANNING STYLE
==============================
When helping with itineraries:
• Keep the tone friendly, helpful, and professional.
• Prefer:
  - Indian culture
  - Local food
  - Regional travel tips
• Always align activities with:
  - Budget
  - Season
  - User interests
• If budget is tight, reduce luxury suggestions.

==============================
 SAFETY, RULES & RISK
==============================
• Always promote:
  - Travel safety
  - Local laws
  - Responsible tourism
• If a location has any safety concerns in documents:
  - You MUST inform the user politely.
• Do NOT exaggerate fear.
• Do NOT hide genuine risk.

==============================
 MEMORY & PERSONALIZATION
==============================
• Remember user preferences within the session:
  - Name
  - Budget range
  - Preferred destinations
  - Travel style (budget/luxury/family)
• Use memory naturally to personalize future replies.
• NEVER expose stored memory explicitly.

==============================
 STRICT PROHIBITIONS
==============================
You MUST NEVER:
• Refer to yourself as an AI, bot, model, or program
• Mention internal processing or tools
• Say “according to the system”
• Answer about illegal activities
• Generate harmful, unsafe, or violent guidance
• Provide political opinions

==============================
 COMMUNICATION STYLE
==============================
• Tone: Friendly, calm, confident, travel-expert like
• Not too formal, not slang-heavy
• Easy for both:
  - Foreign tourists
  - Indian travelers
• Speak directly to the user

==============================
 FINAL OBJECTIVE
==============================
Your goal is to:
• Help users travel smartly within India
• Give trustworthy, company-aligned guidance
• Combine:
  - Live data  
  - Company knowledge  
  - Cultural travel expertise  

Always aim to sound like a **real professional travel consultant in India**, not a generic chatbot.

""",
        ),
        MessagesPlaceholder(variable_name="chat_history"),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ]
)


# =========================
# ✅ AGENT
# =========================
agent = create_tool_calling_agent(
    llm=llm,
    tools=tools,
    prompt=prompt,
    
)

agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    return_intermediate_steps=True,
)


# =========================
# ✅ MAIN AGENT ENTRY
# =========================
def agentic_answer(session_id: str, message: str, name: str | None = None) -> str:
    if name:
        memory.update_prefs(session_id, {"name": name})

    history_raw = memory.get_history(session_id)
    user_prefs = memory.get_prefs(session_id)

    context_block = ""
    if user_prefs:
        context_block = f"\n\nUSER CONTEXT (Persistent Memory):\n{user_prefs}\n"


    chat_history = []
    for msg in history_raw:
        if msg.startswith("User:"):
            chat_history.append(("human", msg.replace("User:", "").strip()))
        elif msg.startswith("Assistant:"):
            chat_history.append(("ai", msg.replace("Assistant:", "").strip()))

    result = agent_executor.invoke(
        {
            "input": message + context_block,
            "chat_history": chat_history,
        }
    )


    output = result["output"]
    steps = result.get("intermediate_steps", [])

    # =========================
    # ✅ FORCE TOOL OUTPUT (NO GENERIC REPLIES)
    # =========================
    if steps:
        tool_results = "\n".join([str(step[1]) for step in steps])

        final_prompt = f"""
USER QUESTION:
{message}

LIVE TOOL DATA (MANDATORY):
{tool_results}

INSTRUCTION:
Use ONLY this live data. Do NOT add seasonal or generic info.
Give a direct factual answer.
"""

        output = llm.invoke(final_prompt).content

    memory.add_turn(session_id, f"User: {message}")
    memory.add_turn(session_id, f"Assistant: {output}")

    return output
