from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

CORPUS_DIR = "data/corpus"

OLLAMA_MODEL_NAME = "mistral:7b-instruct-q4_K_M"
MAX_RAG_CHUNKS = 3
MAX_CHAT_HISTORY = 6

GROQ_API_KEY = "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"
OPENWEATHER_API_KEY = "f97df0c4c5210fabbd1ad4a8a061c2b1"